package com.example.sync_protocol;

import android.os.Environment;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.*;

public class Main {
    public static void invoke() throws IOException {
        String ip = "";
        String urlString = "http://"+ip+":8080";

        Collection A = new ArrayList();
        Collection B = new ArrayList();

        String fileName = new String();
        String fileURL = new String();
        String saveDir = new String();

        String name = String.format("%s/test/", Environment.getExternalStorageDirectory().getAbsolutePath());
        File folder = new File(name);
        Log.println(4, String.valueOf(Log.INFO), String.valueOf(folder) );

        for(File file : folder.listFiles()) {
            B.add(file.getName());
        }

        System.out.println("Files in My System\n"+B);

        URL url = new URL(urlString);

        BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));

        String line;
        line = reader.readLine();

        int i;
        for(i = 0; i < line.length(); i++) {
            if(line.charAt(i) =='e' && line.charAt(i+1) == '=') {
                i = i + 2;
                while(line.charAt(i) != '"') {
                    fileName += line.charAt(i);
                    i++;
                }
                A.add(fileName);
                fileName = "";
            }
        }
        System.out.println("Files in Server\n"+A);

        Collection diff = new ArrayList();
        diff.removeAll(B);
        System.out.println("File To Be Taken from Server\n"+diff);
        Iterator it = diff.iterator();
        while(it.hasNext()) {
            String x = (String)it.next();
            fileURL = "http://"+ip+":8080/get?name="+x;
            saveDir = Environment.getExternalStorageDirectory().getAbsolutePath()+"/test/"+x;
            File out = new File(saveDir);
            new Thread(new Download(fileURL, out)).start();
        }
        reader.close();
    }
}